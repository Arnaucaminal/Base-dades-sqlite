package com.acaminal.basedadessqlite3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Actualitzar extends AppCompatActivity implements View.OnClickListener {

    DBInterface bd;
    Button btnActualitzar;
    EditText editID, editNom, editEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actualitzar);

        btnActualitzar = findViewById(R.id.btnActualitzarAct);
        btnActualitzar.setOnClickListener(this);
        editID = findViewById(R.id.editIdActualitzar);
        editNom = findViewById(R.id.editNomActualitzar);
        editEmail = findViewById(R.id.editEmailActualitzar);
    }

    @Override
    public void onClick(View v) {
        if (v == btnActualitzar) {
            long id;

            // Obtenim la BD
            bd = new DBInterface(this);
            bd.obre();

            // Identificador de la caixa de text
            id = Long.parseLong(editID.getText().toString());

            // Crida a la BD
            boolean result = bd.actualitzarContacte(id, editNom.getText().toString(), editEmail.getText().toString());

            // Comprovem el resultat, si s'ha pogut actualitzar la BD o no
            if (result)
                Toast.makeText(this, "Element modificat", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "No s'ha pogut modificar l'element", Toast.LENGTH_SHORT).show();

            // Tanquem la BD
            bd.tanca();

            // Tanca l'activitat
            finish();
        }
    }
}