package com.acaminal.basedadessqlite3;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Obtenir extends AppCompatActivity implements View.OnClickListener {

    DBInterface bd;
    Button btnObtenir;
    EditText editID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obtenir);
        editID = findViewById(R.id.editIdObtenir);
        btnObtenir = findViewById(R.id.btnObtenirAct);
        btnObtenir.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // Botó obtenir
        if (v == btnObtenir) {
            Cursor c;

            // Obrim la base de dades
            bd = new DBInterface(this);
            bd.obre();

            // Aquest és l'identificador que està escrit a la caixa de text
            long id = Long.parseLong(editID.getText().toString());

            // Crida a la BD
            c = bd.obtenirContacte(id);

            // Comprovem si hi ha hagut algun resultat
            if (c.getCount() != 0) {
                // Mostrem el contacte
                c.moveToFirst();
                Toast.makeText(
                        this,
                        "id: " + c.getString(0) + "\n" +
                                "Nom: " + c.getString(1) + "\n" +
                                "Email: " + c.getString(2),
                        Toast.LENGTH_SHORT
                ).show();
            } else {
                Toast.makeText(this, "id inexistent!", Toast.LENGTH_SHORT).show();
            }

            // Tanquem la BD
            bd.tanca();

            // Tanca l'activitat
            finish();
        }
    }
}