package com.acaminal.basedadessqlite;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Esborrar extends AppCompatActivity implements View.OnClickListener {

    Button btnEsborrar;
    DBInterface bd;
    EditText editID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_esborrar);

        btnEsborrar = findViewById(R.id.btnEsborrarAct);
        btnEsborrar.setOnClickListener(this);
        editID = findViewById(R.id.editIdEsborrar);
    }

    @Override
    public void onClick(View v) {
        if (v == btnEsborrar) {
            // Obrim la BD
            bd = new DBInterface(this);
            bd.obre();

            // Obtenim l'ID de la caixa de text
            long id = Long.parseLong(editID.getText().toString());

            // Cridem la BD
            boolean result = bd.esborraContacte(id);

            // Comprovem el resultat de l'operació
            if (result)
                Toast.makeText(this, "Element esborrat", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "No s'ha pogut esborrar l'element", Toast.LENGTH_SHORT).show();

            // Tanquem la BD
            bd.tanca();

            // Tanquem l'activitat
            finish();
        }
    }
}