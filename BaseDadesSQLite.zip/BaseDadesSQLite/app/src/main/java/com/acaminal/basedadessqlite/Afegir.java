package com.acaminal.basedadessqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Afegir extends AppCompatActivity implements View.OnClickListener {

    DBInterface bd;
    Button btnAfegir;
    EditText editNom, editEmail, editEdat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afegir);

        btnAfegir = findViewById(R.id.btnAfegirAct);
        btnAfegir.setOnClickListener(this);

        editNom = findViewById(R.id.editNom);
        editEmail = findViewById(R.id.editEmail);
        editEdat = findViewById(R.id.editEdat);
    }

    @Override
    public void onClick(View v) {
        if (v == btnAfegir) {
            // Obrim la base de dades
            bd = new DBInterface(this);
            bd.obre();

            // Inserim el contacte.
            int edat = Integer.parseInt(editEdat.getText().toString());
            long result = bd.insereixContacte(editNom.getText().toString(), String.valueOf(edat), editEmail.getText().toString());

            if (result != -1) {
                Toast.makeText(this, "Afegit correctament", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Error a l'afegir", Toast.LENGTH_SHORT).show();
            }

            bd.tanca();
            finish();
        }
    }
}