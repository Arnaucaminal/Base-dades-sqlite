package com.acaminal.basedadessqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    Button btnAfegir, btnObtenir, btnObtenirTots, btnActualitzar, btnEsborrar;
    DBInterface bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bd = new DBInterface(this);

        // Listener de los botones
        btnAfegir = findViewById(R.id.btnAfegir);
        btnAfegir.setOnClickListener(this);

        btnObtenirTots = findViewById(R.id.btnObtenirTots);
        btnObtenirTots.setOnClickListener(this);

        btnObtenir = findViewById(R.id.btnObtenir);
        btnObtenir.setOnClickListener(this);

        btnEsborrar = findViewById(R.id.btnEsborrar);
        btnEsborrar.setOnClickListener(this);

        btnActualitzar = findViewById(R.id.btnActualitzar);
        btnActualitzar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // Afegir
        if (v == btnAfegir) {
            startActivity(new Intent(MainActivity.this, Afegir.class));
        } else if (v == btnObtenir) {
            startActivity(new Intent(MainActivity.this, Obtenir.class));
        } else if (v == btnObtenirTots) {
            // Obrir base de dades
            bd.obre();

            // Crida a la BD per obtenir tots els contactes
            Cursor c = bd.obtenirTotsElsContactes();

            // Movem el cursor a la primera posició
            if (c.moveToFirst()) {
                do {
                    // Mostrem contactes...
                    MostraContacte(c);
                    // ...mentre puguem passar al següent contacte
                } while (c.moveToNext());
            }

            // Tanquem la BD
            bd.tanca();

            Toast.makeText(this, "Tots els contactes mostrats", Toast.LENGTH_SHORT).show();
        } else if (v == btnActualitzar) {
            startActivity(new Intent(MainActivity.this, Actualitzar.class));
        } else if (v == btnEsborrar) {
            startActivity(new Intent(MainActivity.this, Esborrar.class));
        }
    }

    public void MostraContacte(Cursor c) {
        Toast.makeText(
                this,
                "id: " + c.getString(0) + "\n" +
                        "Nom: " + c.getString(1) + "\n" +
                        "Edat: " + c.getString(2) + "\n" +
                        "Email: " + c.getString(3),
                Toast.LENGTH_SHORT
        ).show();
    }
}